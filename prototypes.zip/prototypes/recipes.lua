data:extend(
	{
		{
			type = "recipe",
			name = "item-collector",
			enabled = "true",
			ingredients =
			{
				{"smart-chest", 1},
				{"processing-unit", 20},
				{"solar-panel", 1},
				{"battery", 5}
			},
			result = "item-collector-area"
		}
	}
)
